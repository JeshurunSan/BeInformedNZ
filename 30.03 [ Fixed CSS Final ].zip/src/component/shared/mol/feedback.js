import React from 'react';
import '../../../css/shared/mol/feedback.css'

const Feedback = () => {
    return (
        <div className="Feedback">
            <p>Feedback</p>
        </div>
    );
}

export default Feedback;