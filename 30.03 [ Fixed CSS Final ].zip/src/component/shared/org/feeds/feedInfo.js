//  lIBRARIES
import React from "react";
//  LINKS
// CSS
import "../../../../css/shared/feed-Info.css";

const FeedInfo = () => {
  return <div className="feedInfo">Some information about feeds</div>;
};

export default FeedInfo;
