import React, { Component } from 'react';

class Login extends Component {
    render () {
        return (
            <div>
                <p>Login</p>
            </div>
        );
    }
}

export default Login;