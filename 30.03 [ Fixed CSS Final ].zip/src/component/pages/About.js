import React, { Component } from 'react';

class About extends Component {
    render () {
        return (
            <div>
                <p>About</p>
            </div>
        );
    }
}

export default About;