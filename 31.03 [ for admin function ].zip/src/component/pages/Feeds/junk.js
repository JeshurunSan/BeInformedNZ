// let { filteredFeeds } = this.props.feeds.filter(feeds => {
//   return feeds.indexOf(this.state.search) !== -1;
// });

// constructor() {
//   super();
//   this.state = {
//     search: ""
//   };
// }

// updateSearch(event) {
//   this.setState({ search: event.target.value.substr(0, 25) });
// }

//  25.03 13:30

// let filteredFeeds = feeds.filter(feed =>
//   feed.name.includes(this.state.feed.name)
// );

// constructor() {
//   super();
//   this.state = {
//     feeds: []
//   };
//   console.log(this.state.feeds);
// }

// componentWillMount() {
//   this.setState({
//     feeds: this.props
//   });
// }
