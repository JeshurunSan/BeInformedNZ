import React, { Component } from 'react';

class Contact extends Component {
    render () {
        return (
            <div>
                <p>Contact</p>
            </div>
        );
    }
}

export default Contact;