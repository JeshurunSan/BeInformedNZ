import React, { Component } from "react";
import Feeds from "./Feeds/feeds-page";

class New extends Component {
  render() {
    return (
      <div>
        <Feeds />
      </div>
    );
  }
}

export default New;
